﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ETW Syscall Monitor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ETW Syscall Monitor")]
[assembly: AssemblyCopyright("John Uhlmann")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("537a8a97-8620-4e7a-85ad-863C07654452")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
