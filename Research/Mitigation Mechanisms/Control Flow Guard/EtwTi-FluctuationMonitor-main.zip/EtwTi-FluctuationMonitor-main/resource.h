#define IDR_RT_RCDATA1                  101
