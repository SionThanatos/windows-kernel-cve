#ifndef _POP3_RELAY_
#define _POP3_RELAY_

#include "smbrelay.h"

int HandleIncommingPOP3Request(RELAY *relay, char *destinationhostname,int destinationport);

#endif

