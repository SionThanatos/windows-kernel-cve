# MS08-025

MS08-025  

Vulnerability reference:
 * [MS08-025](https://technet.microsoft.com/library/security/ms08-025)
 * [CVE-2008-1084](http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2008-1084)
 




