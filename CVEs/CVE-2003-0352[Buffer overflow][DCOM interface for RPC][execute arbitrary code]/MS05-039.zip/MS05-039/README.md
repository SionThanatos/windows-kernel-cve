# MS05-039


Vulnerability reference:
 * [MS05-039](https://technet.microsoft.com/library/security/ms05-039)
 * [CVE-2005-1983](http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2005-1983)  
 

## References
+ [MS05039分析](http://www.2cto.com/article/201304/205544.html)
+ [初试MS05039远程溢出攻击](http://blog.csdn.net/shuilan0066/article/details/5920671)  
+ [Ms-05039漏洞原理分析](http://www.ithao123.cn/content-1002576.html)



